@extends('errors::minimal')

@section('title', __('Tidak Ditemukan'))
@section('code', '404')
@section('message', __('Tidak Ditemukan'))
