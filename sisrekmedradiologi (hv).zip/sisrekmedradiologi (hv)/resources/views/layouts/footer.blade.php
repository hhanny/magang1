<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>2020</b>
    </div>
    <strong>Sistem Rekam Medis Radiologi Rumah Sakit Umum Banjar Patroman</strong>
  </footer>
