-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2022 at 07:52 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sisrekmedradiologi`
--

-- --------------------------------------------------------

--
-- Table structure for table `auto_numbers`
--

CREATE TABLE `auto_numbers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_film`
--

CREATE TABLE `master_film` (
  `id_film` int(10) UNSIGNED NOT NULL,
  `tipe_film` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tarif` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_jadwal`
--

CREATE TABLE `master_jadwal` (
  `id_jadwal` int(10) UNSIGNED NOT NULL,
  `jadwal` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_kategori`
--

CREATE TABLE `master_kategori` (
  `id_kategori` int(10) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_layanan`
--

CREATE TABLE `master_layanan` (
  `id_layanan` int(10) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tarif` int(11) NOT NULL,
  `id_kategori` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `master_ruangan`
--

CREATE TABLE `master_ruangan` (
  `id_ruangan` int(10) UNSIGNED NOT NULL,
  `nama_ruangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kelas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_08_03_055212_create_auto_numbers', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2020_07_01_070238_create_master_jadwal_table', 1),
(6, '2020_07_01_070906_create_master_ruangan_table', 1),
(7, '2020_07_01_070936_create_master_film_table', 1),
(8, '2020_07_01_070951_create_master_kategori_table', 1),
(9, '2020_07_01_071040_create_master_layanan_table', 1),
(10, '2020_07_01_073002_create_profile_resepsionis_table', 1),
(11, '2020_07_01_073018_create_profile_radiografer_table', 1),
(12, '2020_07_01_073032_create_profile_dokter_poli_table', 1),
(13, '2020_07_01_073045_create_profile_dokter_radiologi_table', 1),
(14, '2020_07_01_073057_create_profile_kasir_table', 1),
(15, '2020_07_01_075200_create_trans_pasien_table', 1),
(16, '2020_07_01_075347_create_trans_pendaftaran_table', 1),
(17, '2020_07_01_075535_create_trans_pemeriksaan_table', 1),
(18, '2020_07_01_075750_create_trans_tagihan_table', 1),
(19, '2020_09_18_213611_create_notifications_table', 1),
(20, '2022_07_17_164622_create_sessions_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile_dokter_poli`
--

CREATE TABLE `profile_dokter_poli` (
  `id_dokter` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip` int(11) NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` enum('pria','wanita') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_telepon` int(15) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_dokter_poli`
--

INSERT INTO `profile_dokter_poli` (`id_dokter`, `id_user`, `avatar`, `nama`, `nip`, `alamat`, `jenis_kelamin`, `nomor_telepon`, `email`, `created_at`, `updated_at`) VALUES
(1, 5, 'data', 'hahahihi29', 987654, 'Desa Lobener Lor RT 15/04', 'pria', 858604, 'haha12@gmail.com', '2022-07-20 10:26:38', '2022-07-20 10:26:38');

-- --------------------------------------------------------

--
-- Table structure for table `profile_dokter_radiologi`
--

CREATE TABLE `profile_dokter_radiologi` (
  `id_dokter` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip` int(11) NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` enum('pria','wanita') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_telepon` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile_kasir`
--

CREATE TABLE `profile_kasir` (
  `id_kasir` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip` int(11) NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` enum('pria','wanita') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_telepon` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile_radiografer`
--

CREATE TABLE `profile_radiografer` (
  `id_radiografer` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip` int(11) NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` enum('pria','wanita') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_telepon` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile_resepsionis`
--

CREATE TABLE `profile_resepsionis` (
  `id_resepsionis` int(10) UNSIGNED NOT NULL,
  `id_user` int(10) UNSIGNED NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip` int(11) NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` enum('pria','wanita') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_telepon` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trans_pasien`
--

CREATE TABLE `trans_pasien` (
  `id_pasien` int(10) UNSIGNED NOT NULL,
  `nomor_rm` int(11) NOT NULL,
  `id_ruangan` int(10) UNSIGNED NOT NULL,
  `nomor_ktp` int(11) NOT NULL,
  `jenis_pasien` enum('umum','rs') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pasien` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_telepon` int(11) DEFAULT NULL,
  `jenis_asuransi` enum('bjs','umum','lainnya') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_bpjs` int(11) DEFAULT NULL,
  `status_periksa` enum('sudah','pending','belum') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pasien` enum('rs','umum') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trans_pemeriksaan`
--

CREATE TABLE `trans_pemeriksaan` (
  `id_pemeriksaan` int(10) UNSIGNED NOT NULL,
  `id_pasien` int(10) UNSIGNED NOT NULL,
  `id_layanan` int(10) UNSIGNED NOT NULL,
  `id_film` int(10) UNSIGNED NOT NULL,
  `id_jadwal` int(10) UNSIGNED NOT NULL,
  `id_dokter_poli` int(10) UNSIGNED DEFAULT NULL,
  `id_dokter_radiologi` int(10) UNSIGNED DEFAULT NULL,
  `id_radiografer` int(10) UNSIGNED NOT NULL,
  `jenis_pemeriksaan` enum('biasa','penuh') COLLATE utf8mb4_unicode_ci NOT NULL,
  `hasil_foto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surat_rujukan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anamnesa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keluhan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permintaan_tambahan` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waktu_kirim` datetime DEFAULT NULL,
  `waktu_selesai` datetime DEFAULT NULL,
  `durasi` datetime DEFAULT NULL,
  `cito` enum('ya','tidak') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `arus_listrik` int(11) DEFAULT NULL,
  `ffd` int(11) DEFAULT NULL,
  `bsf` int(11) DEFAULT NULL,
  `jumlah_penyinaran` int(11) DEFAULT NULL,
  `dosis_penyinaran` int(11) DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_tarif` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trans_pendaftaran`
--

CREATE TABLE `trans_pendaftaran` (
  `id_pendaftaran` int(10) UNSIGNED NOT NULL,
  `id_pasien` int(10) UNSIGNED NOT NULL,
  `id_resepsionis` int(10) UNSIGNED DEFAULT NULL,
  `id_layanan` int(10) UNSIGNED DEFAULT NULL,
  `id_jadwal` int(10) UNSIGNED NOT NULL,
  `id_dokter_poli` int(10) UNSIGNED DEFAULT NULL,
  `id_dokter_radiologi` int(10) UNSIGNED DEFAULT NULL,
  `nomor_pendaftaran` int(11) NOT NULL,
  `jenis_pemeriksaan` enum('biasa','penuh') COLLATE utf8mb4_unicode_ci NOT NULL,
  `surat_rujukan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trans_tagihan`
--

CREATE TABLE `trans_tagihan` (
  `id_tagihan` int(10) UNSIGNED NOT NULL,
  `id_pemeriksaan` int(10) UNSIGNED NOT NULL,
  `id_kasir` int(10) UNSIGNED NOT NULL,
  `nomor_tagihan` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `tarif` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `role`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'admin', 'admin', 'administrator@gmail.com', NULL, '$2y$10$O/e.WDxkthFf/RLxSy1mIef4k2/fY30PUpAYBWRxqWCWlWpooy3K.', NULL, '2022-07-17 13:43:30', '2022-07-17 13:43:30'),
(4, 'data2906', 'data2906', 'dokterPoli', 'data123@gmail.com', NULL, '$2y$10$cDQIgxQKN4JKBWCjX4uEHOOyVmsSydKROf4r/HbEtANBmPyxMfi4G', NULL, '2022-07-20 10:20:53', '2022-07-20 10:20:53'),
(5, 'hahahihi29', 'hahahihi29', 'dokterPoli', 'haha12@gmail.com', NULL, '$2y$10$AXKNdp2oq54/IuYe.YqR0eTKBVU95aC3XJH4zdua.L4s1nNqUEwOK', NULL, '2022-07-20 10:26:38', '2022-07-20 10:26:38'),
(11, 'ilham', 'ilhamudin123', 'dokterPoli', 'ilham@gmail.com', NULL, '$2y$10$QJR9sgGZ2cLi9d1QBX.HReM7XPwXLAYxmvj7Wlj/bZPaQhOGD4qZC', NULL, '2022-07-20 17:49:19', '2022-07-20 17:49:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auto_numbers`
--
ALTER TABLE `auto_numbers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_film`
--
ALTER TABLE `master_film`
  ADD PRIMARY KEY (`id_film`);

--
-- Indexes for table `master_jadwal`
--
ALTER TABLE `master_jadwal`
  ADD PRIMARY KEY (`id_jadwal`);

--
-- Indexes for table `master_kategori`
--
ALTER TABLE `master_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `master_layanan`
--
ALTER TABLE `master_layanan`
  ADD PRIMARY KEY (`id_layanan`),
  ADD UNIQUE KEY `master_layanan_id_kategori_unique` (`id_kategori`);

--
-- Indexes for table `master_ruangan`
--
ALTER TABLE `master_ruangan`
  ADD PRIMARY KEY (`id_ruangan`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `profile_dokter_poli`
--
ALTER TABLE `profile_dokter_poli`
  ADD PRIMARY KEY (`id_dokter`),
  ADD UNIQUE KEY `profile_dokter_poli_id_user_unique` (`id_user`),
  ADD UNIQUE KEY `profile_dokter_poli_nip_unique` (`nip`),
  ADD UNIQUE KEY `profile_dokter_poli_email_unique` (`email`);

--
-- Indexes for table `profile_dokter_radiologi`
--
ALTER TABLE `profile_dokter_radiologi`
  ADD PRIMARY KEY (`id_dokter`),
  ADD UNIQUE KEY `profile_dokter_radiologi_id_user_unique` (`id_user`),
  ADD UNIQUE KEY `profile_dokter_radiologi_nip_unique` (`nip`),
  ADD UNIQUE KEY `profile_dokter_radiologi_email_unique` (`email`);

--
-- Indexes for table `profile_kasir`
--
ALTER TABLE `profile_kasir`
  ADD PRIMARY KEY (`id_kasir`),
  ADD UNIQUE KEY `profile_kasir_id_user_unique` (`id_user`),
  ADD UNIQUE KEY `profile_kasir_nip_unique` (`nip`),
  ADD UNIQUE KEY `profile_kasir_email_unique` (`email`);

--
-- Indexes for table `profile_radiografer`
--
ALTER TABLE `profile_radiografer`
  ADD PRIMARY KEY (`id_radiografer`),
  ADD UNIQUE KEY `profile_radiografer_id_user_unique` (`id_user`),
  ADD UNIQUE KEY `profile_radiografer_nip_unique` (`nip`),
  ADD UNIQUE KEY `profile_radiografer_email_unique` (`email`);

--
-- Indexes for table `profile_resepsionis`
--
ALTER TABLE `profile_resepsionis`
  ADD PRIMARY KEY (`id_resepsionis`),
  ADD UNIQUE KEY `profile_resepsionis_id_user_unique` (`id_user`),
  ADD UNIQUE KEY `profile_resepsionis_nip_unique` (`nip`),
  ADD UNIQUE KEY `profile_resepsionis_email_unique` (`email`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `trans_pasien`
--
ALTER TABLE `trans_pasien`
  ADD PRIMARY KEY (`id_pasien`),
  ADD UNIQUE KEY `trans_pasien_nomor_rm_unique` (`nomor_rm`),
  ADD UNIQUE KEY `trans_pasien_nomor_ktp_unique` (`nomor_ktp`),
  ADD UNIQUE KEY `trans_pasien_nomor_bpjs_unique` (`nomor_bpjs`),
  ADD KEY `trans_pasien_id_ruangan_foreign` (`id_ruangan`);

--
-- Indexes for table `trans_pemeriksaan`
--
ALTER TABLE `trans_pemeriksaan`
  ADD PRIMARY KEY (`id_pemeriksaan`),
  ADD UNIQUE KEY `trans_pemeriksaan_id_jadwal_unique` (`id_jadwal`),
  ADD KEY `trans_pemeriksaan_id_pasien_foreign` (`id_pasien`),
  ADD KEY `trans_pemeriksaan_id_layanan_foreign` (`id_layanan`),
  ADD KEY `trans_pemeriksaan_id_dokter_poli_foreign` (`id_dokter_poli`),
  ADD KEY `trans_pemeriksaan_id_dokter_radiologi_foreign` (`id_dokter_radiologi`),
  ADD KEY `trans_pemeriksaan_id_radiografer_foreign` (`id_radiografer`),
  ADD KEY `trans_pemeriksaan_id_film_foreign` (`id_film`);

--
-- Indexes for table `trans_pendaftaran`
--
ALTER TABLE `trans_pendaftaran`
  ADD PRIMARY KEY (`id_pendaftaran`),
  ADD UNIQUE KEY `trans_pendaftaran_id_pasien_unique` (`id_pasien`),
  ADD UNIQUE KEY `trans_pendaftaran_nomor_pendaftaran_unique` (`nomor_pendaftaran`),
  ADD KEY `trans_pendaftaran_id_resepsionis_foreign` (`id_resepsionis`),
  ADD KEY `trans_pendaftaran_id_dokter_poli_foreign` (`id_dokter_poli`),
  ADD KEY `trans_pendaftaran_id_dokter_radiologi_foreign` (`id_dokter_radiologi`),
  ADD KEY `trans_pendaftaran_id_jadwal_foreign` (`id_jadwal`),
  ADD KEY `trans_pendaftaran_id_layanan_foreign` (`id_layanan`);

--
-- Indexes for table `trans_tagihan`
--
ALTER TABLE `trans_tagihan`
  ADD PRIMARY KEY (`id_tagihan`),
  ADD UNIQUE KEY `trans_tagihan_id_pemeriksaan_unique` (`id_pemeriksaan`),
  ADD UNIQUE KEY `trans_tagihan_nomor_tagihan_unique` (`nomor_tagihan`),
  ADD KEY `trans_tagihan_id_kasir_foreign` (`id_kasir`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auto_numbers`
--
ALTER TABLE `auto_numbers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_film`
--
ALTER TABLE `master_film`
  MODIFY `id_film` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_jadwal`
--
ALTER TABLE `master_jadwal`
  MODIFY `id_jadwal` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_kategori`
--
ALTER TABLE `master_kategori`
  MODIFY `id_kategori` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_layanan`
--
ALTER TABLE `master_layanan`
  MODIFY `id_layanan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `master_ruangan`
--
ALTER TABLE `master_ruangan`
  MODIFY `id_ruangan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `profile_dokter_poli`
--
ALTER TABLE `profile_dokter_poli`
  MODIFY `id_dokter` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `profile_dokter_radiologi`
--
ALTER TABLE `profile_dokter_radiologi`
  MODIFY `id_dokter` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_kasir`
--
ALTER TABLE `profile_kasir`
  MODIFY `id_kasir` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_radiografer`
--
ALTER TABLE `profile_radiografer`
  MODIFY `id_radiografer` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_resepsionis`
--
ALTER TABLE `profile_resepsionis`
  MODIFY `id_resepsionis` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trans_pasien`
--
ALTER TABLE `trans_pasien`
  MODIFY `id_pasien` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trans_pemeriksaan`
--
ALTER TABLE `trans_pemeriksaan`
  MODIFY `id_pemeriksaan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trans_pendaftaran`
--
ALTER TABLE `trans_pendaftaran`
  MODIFY `id_pendaftaran` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trans_tagihan`
--
ALTER TABLE `trans_tagihan`
  MODIFY `id_tagihan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `master_layanan`
--
ALTER TABLE `master_layanan`
  ADD CONSTRAINT `master_layanan_id_kategori_foreign` FOREIGN KEY (`id_kategori`) REFERENCES `master_kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `trans_pasien`
--
ALTER TABLE `trans_pasien`
  ADD CONSTRAINT `trans_pasien_id_ruangan_foreign` FOREIGN KEY (`id_ruangan`) REFERENCES `master_ruangan` (`id_ruangan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `trans_pemeriksaan`
--
ALTER TABLE `trans_pemeriksaan`
  ADD CONSTRAINT `trans_pemeriksaan_id_dokter_poli_foreign` FOREIGN KEY (`id_dokter_poli`) REFERENCES `profile_dokter_poli` (`id_dokter`) ON DELETE CASCADE,
  ADD CONSTRAINT `trans_pemeriksaan_id_dokter_radiologi_foreign` FOREIGN KEY (`id_dokter_radiologi`) REFERENCES `profile_dokter_radiologi` (`id_dokter`) ON DELETE CASCADE,
  ADD CONSTRAINT `trans_pemeriksaan_id_film_foreign` FOREIGN KEY (`id_film`) REFERENCES `master_film` (`id_film`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `trans_pemeriksaan_id_jadwal_foreign` FOREIGN KEY (`id_jadwal`) REFERENCES `master_jadwal` (`id_jadwal`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `trans_pemeriksaan_id_layanan_foreign` FOREIGN KEY (`id_layanan`) REFERENCES `master_layanan` (`id_layanan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `trans_pemeriksaan_id_pasien_foreign` FOREIGN KEY (`id_pasien`) REFERENCES `trans_pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `trans_pemeriksaan_id_radiografer_foreign` FOREIGN KEY (`id_radiografer`) REFERENCES `profile_radiografer` (`id_radiografer`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `trans_pendaftaran`
--
ALTER TABLE `trans_pendaftaran`
  ADD CONSTRAINT `trans_pendaftaran_id_dokter_poli_foreign` FOREIGN KEY (`id_dokter_poli`) REFERENCES `profile_dokter_poli` (`id_dokter`) ON DELETE CASCADE,
  ADD CONSTRAINT `trans_pendaftaran_id_dokter_radiologi_foreign` FOREIGN KEY (`id_dokter_radiologi`) REFERENCES `profile_dokter_radiologi` (`id_dokter`) ON DELETE CASCADE,
  ADD CONSTRAINT `trans_pendaftaran_id_jadwal_foreign` FOREIGN KEY (`id_jadwal`) REFERENCES `master_jadwal` (`id_jadwal`) ON DELETE CASCADE,
  ADD CONSTRAINT `trans_pendaftaran_id_layanan_foreign` FOREIGN KEY (`id_layanan`) REFERENCES `master_layanan` (`id_layanan`) ON DELETE CASCADE,
  ADD CONSTRAINT `trans_pendaftaran_id_pasien_foreign` FOREIGN KEY (`id_pasien`) REFERENCES `trans_pasien` (`id_pasien`) ON DELETE CASCADE,
  ADD CONSTRAINT `trans_pendaftaran_id_resepsionis_foreign` FOREIGN KEY (`id_resepsionis`) REFERENCES `profile_resepsionis` (`id_resepsionis`) ON DELETE CASCADE;

--
-- Constraints for table `trans_tagihan`
--
ALTER TABLE `trans_tagihan`
  ADD CONSTRAINT `trans_tagihan_id_kasir_foreign` FOREIGN KEY (`id_kasir`) REFERENCES `profile_kasir` (`id_kasir`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `trans_tagihan_id_pemeriksaan_foreign` FOREIGN KEY (`id_pemeriksaan`) REFERENCES `trans_pemeriksaan` (`id_pemeriksaan`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
