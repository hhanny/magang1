<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DokterPoli extends Model
{
    protected $table = "profile_dokter_poli";

    protected $guarded = [''];
    
}
