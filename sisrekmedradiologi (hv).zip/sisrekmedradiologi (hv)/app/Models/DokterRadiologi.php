<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DokterRadiologi extends Model
{
    protected $table = "profile_dokter_radiologi";

    protected $guarded = [''];
}
